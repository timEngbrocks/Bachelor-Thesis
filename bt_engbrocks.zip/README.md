# Bachelor Thesis by Tim Engbrocks

Topic:

Development of a Concept for the Monitoring of Decentralized Identity Solutions Based on DevOps Concepts

## Download current main build

[Last build](https://nightly.link/timEngbrocks/Bachelor-Thesis/workflows/build_latex/main/build.zip?h=d868a12c9def8cc64cc3e0850f254f114ac79de6)
